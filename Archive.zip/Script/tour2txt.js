// require base functions
var tf 		= require('./tourfile.js');
tf.ConvertResultsIntoTxt();
tf.checkResults();